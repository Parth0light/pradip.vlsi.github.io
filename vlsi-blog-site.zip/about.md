---
title: About
permalink: /about/
---

# About VLSI Hub

VLSI Hub shares practical verification knowledge — from **HDL basics** to **UVM best practices** — with clean examples and real-world tips.
