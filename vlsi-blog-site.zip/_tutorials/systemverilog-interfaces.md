---
title: SystemVerilog Interfaces
summary: Cleanly bundle signals and protocols using interfaces.
---

## Why Interfaces?

They reduce port clutter and enable modports for direction control.

## Example

```systemverilog
interface bus_if(input bit clk);
  logic [7:0] addr, wdata, rdata;
  logic we, valid, ready;
  modport master(input ready, rdata, output addr, wdata, we, valid);
  modport slave (input addr, wdata, we, valid, output ready, rdata);
endinterface
```
