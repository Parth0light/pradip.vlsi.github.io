---
title: UVM Testbench Basics
summary: Build blocks of a reusable UVM environment.
---

- Components: `env`, `agent`, `seqr`, `drv`, `mon`
- Transactions via sequences
- Factory & config DB for reuse
