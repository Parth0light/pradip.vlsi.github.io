---
title: Getting Started with Verilog
summary: A quick path to writing and simulating your first Verilog module.
---

## What is Verilog?

Verilog is a hardware description language (HDL) used to model digital systems.

## Your First Module

```verilog
module and2(input a, input b, output y);
  assign y = a & b;
endmodule
```

## Testbench Sketch

```verilog
module tb;
  reg a, b; wire y;
  and2 dut(.a(a), .b(b), .y(y));
  initial begin
    a=0; b=0; #10;
    a=1; b=0; #10;
    a=0; b=1; #10;
    a=1; b=1; #10;
  end
endmodule
```
