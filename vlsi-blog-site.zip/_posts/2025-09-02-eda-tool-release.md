---
title: New Open-Source EDA Tool Release
tags: [news, tools]
---

A promising open-source EDA tool just shipped a new version with faster synthesis and better reporting.
Stay tuned for a deep dive.
