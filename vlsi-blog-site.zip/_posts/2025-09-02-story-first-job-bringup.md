---
title: Story — The Night We Brought Up First Silicon
tags: [story, tapeout]
---

It was 2:13 AM when the UART finally chirped back...
